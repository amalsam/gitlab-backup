package com.ust.base;

import java.awt.Window;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.ust.utilities.PropertyReader;
import com.ust.utilities.ReportManager;

public class SetUp {
    public static WebDriver driver;
    public static Properties prop;
    public static ExtentReports extent;

    // Constructor to initialize properties and ExtentReports
    public SetUp() {
        prop = PropertyReader.initProperties();
        extent = ReportManager.createIntance();
    }

    // Method to get the WebDriver instance based on browser choice from properties
    public static WebDriver getBrowser(String browser_choice) {
        browser_choice = prop.getProperty("browser");
        try {
            if (browser_choice.equalsIgnoreCase("chrome")) {
                driver = DriverSetup.getChromeDriver();
            } else if (browser_choice.equalsIgnoreCase("edge")) {
                driver = DriverSetup.getEdgeDriver();
            } else {
                throw new Exception("Invalid Browser Name in property file");
            }
        } catch (Exception e) {
            e.getMessage();
        }
        return driver;
    }

    // Method to capture a screenshot
    public static void takeScreenshot(String toPath) {
        File srcfile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        try {
            FileUtils.copyFile(srcfile, new File(toPath));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method to get current timestamp in the format yyyy.MM.dd.HH.mm.ss
    public static String getTimeStamp() {
        return new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
    }

    // Method to pause execution for a specified duration
    public static void sleep(long milli) {
        try {
            Thread.sleep(milli);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    // Method to wait until element becomes visible
    public static WebElement waitUntil(WebElement element) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        return wait.until(ExpectedConditions.visibilityOf(element));
    }

    // Method to get text from an alert
    public String getAlertMsg() {
        return driver.switchTo().alert().getText();
    }

    // Method to accept an alert
    public void acceptAlertMsg() {
        driver.switchTo().alert().accept();
    }
    
    
    
    public static void switchTab(int n) {
    	//Set<String> win=driver.getWindowHandles();
    	ArrayList<String> newTb = new ArrayList<String>(driver.getWindowHandles());
    	
    	
    	driver.switchTo().window(newTb.get(n));
    	
    }
    
   public static void swichToParentFrame() {
	   driver.switchTo().parentFrame();
   }
}
