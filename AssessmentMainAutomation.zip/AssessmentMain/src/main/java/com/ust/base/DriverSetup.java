package com.ust.base;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

public class DriverSetup {
    // Static variable to hold the WebDriver instance
    private static WebDriver driver;
    
    // Method to get a ChromeDriver instance
    public static WebDriver getChromeDriver() {
        // Create ChromeOptions instance
        ChromeOptions co = new ChromeOptions();
        // Add Chrome  arguments
        co.addArguments("--disable-infobars");
        co.addArguments("--disable-notifications");
        co.addArguments("--start-maximized");
        // Create a new ChromeDriver with the ChromeOptions
        driver = new ChromeDriver(co);
        // Set implicit wait timeout
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        return driver;
    }
    
    // Method to get an EdgeDriver instance
    public static WebDriver getEdgeDriver() {
        // Create EdgeOptions instance
        EdgeOptions eo = new EdgeOptions();
        // Add Edge arguments
        eo.addArguments("--disable-infobars");
        eo.addArguments("--disable-notifications");
        eo.addArguments("--start-maximized");
        // Create a new EdgeDriver with the EdgeOptions
        driver = new EdgeDriver(eo);
        // Set implicit wait timeout
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        return driver;
    }
}
