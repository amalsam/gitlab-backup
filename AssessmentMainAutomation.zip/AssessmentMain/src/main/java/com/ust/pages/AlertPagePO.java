package com.ust.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AlertPagePO extends NavigationBarPO {
	WebDriver driver;
	
	@FindBy(xpath = "//button[text()='Click the button to display an alert box:']") WebElement clickAlertButton;
	
	@FindBy(xpath = "//button[text()='Click the button to demonstrate the Input box.']") WebElement clickInputAlertButton;
	@FindBy(className = "demo-frame")List<WebElement> iframes;
	@FindBy(xpath = "//a[contains(text(),'Input Alert')]") WebElement inputAlert;
	WebElement demo;
	public AlertPagePO(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver,this);	
	}
	
	public void clickalertButton(){
		//clickAlertButton.click();
		driver.switchTo().frame(iframes.get(0));
		clickAlertButton.click();
	}
	
	public void openInputAlert() {
		inputAlert.click();
		driver.switchTo().frame(iframes.get(1));
		clickInputAlertButton.click();
		
		
	}
	
	public String getTextIntheFrame() {
		return demo.getText();
		
	}
	
	
	

}
