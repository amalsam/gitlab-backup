package com.ust.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RegistrationPagePO extends NavigationBarPO{
	WebDriver driver;
	
	@FindBy(xpath ="//label[text()='First Name:']//following-sibling::input")public WebElement firstName;
	@FindBy(xpath ="//label[text()='Last Name:']//following-sibling::input")public WebElement LastName;
	@FindBy(xpath ="//label[text()='Phone Number:']//following-sibling::input")public WebElement phoneNo;
	@FindBy(xpath ="//label[text()='E-mail:']//following-sibling::input")public WebElement emailID;
	@FindBy(xpath ="//label[text()='Username:']//following-sibling::input")public WebElement userName;
	@FindBy(xpath ="//label[text()='Password:']//following-sibling::input")public WebElement password;
	@FindBy(xpath ="//label[text()='Confirm Password:']//following-sibling::input")public WebElement conPassword;
	@FindBy(xpath ="//input[@value='submit']")public WebElement submitButton;
	@FindBy(xpath ="//label[text()=' Cricket']//child::input")public WebElement cricketCheckBox;
	@FindBy(xpath = "//label[text()='This field is required.']")public List<WebElement> errmsgs;
	

	public RegistrationPagePO(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver,this);	
	}
	
	
}
