package com.ust.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class NavigationBarPO {
	WebDriver driver;
	
	@FindBy(linkText = "Alert") WebElement alertLink;
	@FindBy(linkText = "Home") WebElement homeLink;
	@FindBy(linkText = "Interaction") WebElement interaction;
	@FindBy(linkText = "Frames and Windows") WebElement framesandwindows;
	@FindBy(linkText = "Dynamic Elements") WebElement dynamicElementLink;
	@FindBy(linkText = "Registration") WebElement registrationLink;
	
	By enterWebsite = By.linkText("ENTER TO THE TESTING WEBSITE");
	
	
	
	public NavigationBarPO(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver,this);
	}
	
	public AlertPagePO openAlertPage() {
		alertLink.click();
		return new AlertPagePO(driver);
	}
	
	public RegistrationPagePO openRegPage() {
		registrationLink.click();
		return new RegistrationPagePO(driver);
	}
	
	public void entertoWebsite() {
		driver.findElement(enterWebsite).click();
	}
	

	
	

}
