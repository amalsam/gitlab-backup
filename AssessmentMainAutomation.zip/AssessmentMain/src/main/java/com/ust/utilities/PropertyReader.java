package com.ust.utilities;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class PropertyReader {
    // Static variable to hold the Properties object
    private static Properties prop;

    // Method to initialize the Properties object and load properties from file
    public static Properties initProperties() {
        // If Properties object is not initialized, create it and load properties
        if (prop == null) {
            prop = new Properties();
            // Path to the properties file
            String path = System.getProperty("user.dir") + "\\src\\test\\resources\\objectrepository\\object.properties";
            FileReader file;
            try {
                // Create a FileReader object to read the properties file
                file = new FileReader(path);
                // Load properties from the file into the Properties object
                prop.load(file);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return prop;
    }

   
}
