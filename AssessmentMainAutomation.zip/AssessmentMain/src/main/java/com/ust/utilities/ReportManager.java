package com.ust.utilities;

import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.ust.base.SetUp;

public class ReportManager {
    // Static variables to hold ExtentReports, ExtentSparkReporter, and ExtentTest objects
    public static ExtentReports extent;
    public static ExtentSparkReporter htmlReporter;
    public static ExtentTest test;
    
    // Method to create and configure an instance of ExtentReports
    public static ExtentReports createIntance() {
        // Generate a unique report name using the timestamp
        String repname = "TestReport-" + SetUp.getTimeStamp() + ".html";
        // Create an ExtentSparkReporter with the specified file path
        htmlReporter = new ExtentSparkReporter(System.getProperty("user.dir") + "//Reports//" + repname);
        // Configure the HTML report settings
        htmlReporter.config().setDocumentTitle("Extent Report Demo");
        htmlReporter.config().setReportName("Test Report");
        htmlReporter.config().setTimelineEnabled(true);
        htmlReporter.config().setTheme(Theme.DARK);
        htmlReporter.config().setTimeStampFormat("MM/dd/yyyy HH:mm:ss");
        // Create an instance of ExtentReports
        extent = new ExtentReports();
        // Attach the ExtentSparkReporter to the ExtentReports instance
        extent.attachReporter(htmlReporter);
        // Set system information for the report
        extent.setSystemInfo("Os", "Windows");
        extent.setSystemInfo("HostName", "localhost");
        extent.setSystemInfo("Enviornment", "QA");
        extent.setSystemInfo("UserName", "Amal");
        return extent;
    }

    // Method to create a new ExtentTest instance for a test method
    public static ExtentTest createTest(ITestResult result, ExtentReports report) {
        // Create a new ExtentTest instance with the test method name
    	String testName = "Test " + result.getName();
        test = report.createTest(testName);
        return test;
    }
}
