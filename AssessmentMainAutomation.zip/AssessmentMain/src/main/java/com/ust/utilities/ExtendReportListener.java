package com.ust.utilities;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.ust.base.SetUp;

// This class implements the TestNG interface ITestListener to customize test execution behavior
public class ExtendReportListener implements ITestListener {

    ExtentTest test;
    ExtentReports report;

    // This method gets invoked before the start of test execution
    public void onStart(ITestContext context) {
        // Create a new ExtentReports instance
        report = ReportManager.createIntance();
    }

    // This method gets invoked before each test method starts execution
    public void onTestStart(ITestResult result) {
        // Create a new test in the Extent report for the current test method
        test = ReportManager.createTest(result, report);
    }

    // This method gets invoked when a test method passes
    public void onTestSuccess(ITestResult result) {
        // Log the test status as PASS in the Extent report
        test.log(Status.PASS, result.getName() + " Passed");
        // Capture a screenshot and add it to the Extent report
        String path = System.getProperty("user.dir") + "/screenshots/pass/" + result.getName() + SetUp.getTimeStamp() + "pass.png";
        SetUp.takeScreenshot(path);
        test.addScreenCaptureFromPath(path);
    }

    // This method gets invoked when a test method fails
    public void onTestFailure(ITestResult result) {
        // Log the test status as FAIL in the Extent report
        test.log(Status.FAIL, result.getName() + " Failed");
        // Capture a screenshot and add it to the Extent report
        String path = System.getProperty("user.dir") + "/screenshots/failed/" + result.getName() + SetUp.getTimeStamp() + "fail.png";
        SetUp.takeScreenshot(path);
        test.addScreenCaptureFromPath(path);
    }

    // This method gets invoked when a test method is skipped
    public void onTestSkipped(ITestResult result) {
       
    }

    // This method gets invoked after all tests have finished execution
    public void onFinish(ITestContext context) {
        // Flush the Extent report to write all the logs to the output file
        report.flush();
    }
}
