package com.ust.utilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader {
    
    /*
     * This method retrieves data from an Excel file.
     * It takes the file path and sheet name as arguments.
     * It returns a 2D string array containing the Excel data.
     */
    public static String[][] getExcelData(String path, String sheetname) {
        XSSFWorkbook workbook = null;
        XSSFSheet sheet;
        try {
            // Create a FileInputStream to read the Excel file
            FileInputStream fis = new FileInputStream(System.getProperty("user.dir") + path);
            // Create an XSSFWorkbook object to represent the Excel workbook
            workbook = new XSSFWorkbook(fis);
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        // Get the specified sheet from the workbook
        sheet = workbook.getSheet(sheetname);
        
        // Get the number of rows and columns in the sheet
        int rowCount = sheet.getPhysicalNumberOfRows();
        int colCount = sheet.getRow(0).getPhysicalNumberOfCells();
        
        // Create a 2D array to store the Excel data
        String data[][] = new String[rowCount][colCount];
        
        // Create a DataFormatter object to format cell values
        DataFormatter df = new DataFormatter();
        // Loop through each row and column to retrieve cell data
        for (int i = 0; i < rowCount; i++) {
            for (int j = 0; j < colCount; j++) {
                // Format and store the cell value in the data array
                data[i][j] = df.formatCellValue(sheet.getRow(i).getCell(j));
            }
        }
        
        return data;
    }
}

