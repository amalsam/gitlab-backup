package com.ust.stepdefenitions;

import static org.testng.Assert.assertTrue;

import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.aventstack.extentreports.gherkin.model.Scenario;
import com.ust.base.SetUp;
import com.ust.pages.HomePagePO;
import com.ust.pages.RegistrationPagePO;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class RegistrationTest {
	HomePagePO home;
	RegistrationPagePO reg;
	WebDriver driver;
	
	@Before
    public void setUp() {
	        driver = new ChromeDriver();
	               
    }  
    @After
    public void tearDown() {
    	driver.quit();
    }

@Given("user in registration page")
public void user_in_registration_page() {
	home= new HomePagePO(driver);
	driver.get("https://www.way2automation.com/demo.html");
	reg =home.openRegPage();
	ArrayList<String> newTb = new ArrayList<String>(driver.getWindowHandles());
	
	
	driver.switchTo().window(newTb.get(1));
	  reg.entertoWebsite();
	  reg=reg.openRegPage();
	  newTb = new ArrayList<String>(driver.getWindowHandles());
		
		
		driver.switchTo().window(newTb.get(2));
   
}
@When("user enters first name {string}")
public void user_enters_first_name(String string) {
    reg.firstName.sendKeys(string);
}
@When("user enters last name {string}")
public void user_enters_last_name(String string) {
    reg.LastName.sendKeys(string);
}
@When("user select hobby {string}")
public void user_select_hobby(String string) {
  reg.cricketCheckBox.click();
}
@When("user add phone number {string}")
public void user_add_phone_number(String string) {
    reg.phoneNo.sendKeys(string);
}
@When("user enter username {string}")
public void user_enter_username(String string) {
   reg.userName.sendKeys(string);
}
@When("user enter email {string}")
public void user_enter_email(String string) {
   reg.emailID.sendKeys(string);
}
@When("user enter password {string}")
public void user_enter_password(String string) {
    reg.password.sendKeys(string);
}
@When("user enter confirm password {string}")
public void user_enter_confirm_password(String string) {
   reg.conPassword.sendKeys(string);
}
@When("user click register button")
public void user_click_register_button() {
    reg.submitButton.click();
}

@Then("user data should register")
public void user_data_should_register() {
   assertTrue(true);
}


@Then("error message should be dispalyed")
public void error_message_should_be_dispalyed() {
	assertTrue(reg.errmsgs.get(0).getText().equals("This field is required."));
   
}

}
