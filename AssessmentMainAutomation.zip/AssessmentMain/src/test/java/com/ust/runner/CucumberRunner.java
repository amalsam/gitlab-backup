package com.ust.runner;



import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
		features = "classpath:features",
		glue = "com.ust.stepdefenitions",
		plugin = {"me.jvt.cucumber.report.PrettyReports:CucumberReports"}
		
		)

public class CucumberRunner extends AbstractTestNGCucumberTests{

}


