package com.ust.testngtests;

import org.testng.annotations.Test;

import com.ust.base.SetUp;
import com.ust.pages.AlertPagePO;
import com.ust.pages.HomePagePO;
import com.ust.utilities.ExtendReportListener;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;

import static org.testng.Assert.assertEquals;



import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;


@Listeners(ExtendReportListener.class)
public class VerifyAlertBox  extends SetUp{
	WebDriver driver;
	HomePagePO home;
	AlertPagePO alertpage;
	
	
	
	
	//verifying alert message
  @Test(priority = 1)
  public void verifyAlertText() {
	  alertpage=home.openAlertPage();
	  switchTab(1);
	  alertpage.entertoWebsite();
	  alertpage.openAlertPage();
	  switchTab(2);
	  alertpage.clickalertButton();
	  assertEquals(getAlertMsg(),"I am an alert box!");
	  acceptAlertMsg();
	  swichToParentFrame();  
  }
  
  @Test(priority = 2)
  public void verifyAlertInputAlert() {
	  alertpage.openInputAlert();
	  acceptAlertMsg(); 
	  assertEquals(alertpage.getTextIntheFrame(),"Hello Harry Potter! How are you today?");
	  
  }
  
  
  
  
  @BeforeClass
  public void beforeClass() {
	  driver = SetUp.getBrowser(prop.getProperty("browser"));
	  driver.get(prop.getProperty("baseurl"));
	  home=new HomePagePO(driver);
	  
  }

  @AfterClass
  public void afterClass() {
	  driver.quit();
  }

}
