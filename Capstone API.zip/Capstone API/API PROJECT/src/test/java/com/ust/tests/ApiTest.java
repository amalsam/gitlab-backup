package com.ust.tests;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.endpoints.Endpoints;
import com.ust.utils.ExcelReader;
import com.ust.utils.ExtendReportListener;

import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import static org.hamcrest.Matchers.equalTo;

@Listeners(ExtendReportListener.class)

public class ApiTest {
	Endpoints endpoint;
	Response response;
	
	@BeforeMethod
	public void setup() {
        endpoint = new Endpoints(); // creating object for endpoints
    }
	
  @Test(dataProvider = "dp",priority = 0)
  public void verifyCreateOrder(String id,String petId,String quantity,String shipDate,String status,String complete) {
	  response = endpoint.createOrder(id, petId, quantity, shipDate, status, complete);
	  response.then().assertThat().body(JsonSchemaValidator.matchesJsonSchemaInClasspath("createorderschema.json")) //validating schema
	  .and().body("status",equalTo(status)); //validating with data
	  assertEquals(response.statusCode(),200); // validating with status code	200
	  
  }
  
  @Test(priority = 1)
  public void verifyGetInventory() {
	  response = endpoint.getInventory();
	  response.then().assertThat().body(JsonSchemaValidator.matchesJsonSchemaInClasspath("inventory.json")); //validating with json schema
	 
	  assertEquals(response.statusCode(),200); // validating with status code 200
	  
  }
  
  @Test(priority = 2)
  public void verifyGetOrder() {
	  response = endpoint.getOrder(8);
	  response.then().assertThat().body(JsonSchemaValidator.matchesJsonSchemaInClasspath("order.json")); //validating with json schema
	  //response.then().body("id", equalTo(8));
	  assertEquals( response.statusCode(),200); //validating status code 200
	  
  }
  
  @Test(priority = 3)
  public void verifyDeleteOrder() {
	  response = endpoint.getOrder(10);
	  response.then().assertThat().body(JsonSchemaValidator.matchesJsonSchemaInClasspath("deleteorderschema.json")); //validating with json schema
	  assertEquals(response.statusCode(),200 );//validating status code 200
	  
  }
  
  
  
  @DataProvider
  public String[][]  dp() {
	  return ExcelReader.getExcelData("\\src\\test\\resources\\exceldata\\testdata.xlsx", "CREATE ORDER"); //Reading data from excel for dataprovider
  }
}
