package com.ust.routes;


/*
*Class for store all urls
*/
public class Routes {
	public static final String BASEURL = "https://petstore.swagger.io";
	public static final String CREATE_ORDER_PATH = "/v2/store/order";
	public static final String GET_ORDER_PATH = "/v2/store/order/";
	public static final String GET_INVETORY_PATH = "/v2/store/inventory";
	public static final String DELETE_ORDER_PATH = "/v2/store/order/";
}
