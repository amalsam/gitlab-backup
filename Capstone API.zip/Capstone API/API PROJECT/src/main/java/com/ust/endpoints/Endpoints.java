package com.ust.endpoints;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static io.restassured.RestAssured.given;

import com.ust.payloads.CreateOrderPOJO;
import com.ust.routes.Routes;

public class Endpoints {
	
	
	//method to set base url and relaxed http validation
	private void initRest() {
		RestAssured.baseURI = Routes.BASEURL;
		RestAssured.useRelaxedHTTPSValidation();
		
	}
	
	
	//request a post method to create order and returns a Response Object
	public Response createOrder(String id,String petId,String quantity,String shipDate,String status,String complete) {
		CreateOrderPOJO orderPayload = new CreateOrderPOJO();  //object for payload
		orderPayload.setId(Integer.parseInt(id));
		orderPayload.setPetId(Integer.parseInt(petId));
		orderPayload.setQuantity(Integer.parseInt(quantity));
		orderPayload.setShipDate(shipDate);
		orderPayload.setStatus(status);
		orderPayload.setComplete(Boolean.parseBoolean(complete));
		initRest();
		return given()
				.contentType(ContentType.JSON)//setting header content type
				.body(orderPayload)//passing payload
				.post(Routes.CREATE_ORDER_PATH);
	}
	
	
	//request a get method to get deteils of inventory and returns a Response Object
	public Response getInventory() {
		initRest();
		return given()
		.when()
		.get(Routes.GET_INVETORY_PATH);	
	}
	
	
	//request a get method to get deteils of an order with id and returns a Response Object
	public Response getOrder(int id) {
		initRest();
		return given()
		.accept(ContentType.JSON)
		.when()
		.get(Routes.DELETE_ORDER_PATH+id);
		
		
	}
	
	//request a delete method to delete an order with id and returns a Response Object
	public Response deleteOrder(int id) {
		return 
				given()
				.when()
				.delete(Routes.DELETE_ORDER_PATH+id);
			
	}
	

}
