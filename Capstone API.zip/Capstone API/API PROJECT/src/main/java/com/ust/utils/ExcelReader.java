package com.ust.utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


/*
 * class for reading data from excel
 * 
 */
public class ExcelReader {
	
    /*
     * this method will return a 2d string array containing data in excel
     */
   
    public static String[][] getExcelData(String path, String sheetname) {
        XSSFWorkbook workbook = null;
        XSSFSheet sheet;
        try {
            
            FileInputStream fis = new FileInputStream(System.getProperty("user.dir") + path);
            
            workbook = new XSSFWorkbook(fis);
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        
        sheet = workbook.getSheet(sheetname);
        
       
        int rowCount = sheet.getPhysicalNumberOfRows();
        int colCount = sheet.getRow(0).getPhysicalNumberOfCells();
        
        
        String data[][] = new String[rowCount][colCount];
        
      
        DataFormatter df = new DataFormatter();
        
        for (int i = 0; i < rowCount; i++) {
            for (int j = 0; j < colCount; j++) {
                
                data[i][j] = df.formatCellValue(sheet.getRow(i).getCell(j));
            }
        }
        
        return data;
    }
}

