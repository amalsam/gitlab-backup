package com.ust.pharmeasy.locators;

public class TopProductPageLocators {
	public static final String VITAMINXPATH = "//input[@value='9195']";
	public static final String VITAMINWAITXPATH = "//div[text() = 'Vitamin']";
	public static final String LIVEASYXPATH = "//input[@value='71972']";
	public static final String BELOWNINENINEXPATH = "(//input[@class='jss4' and @type='checkbox' and @value='undefined'])[1]";
	public static final String TOPPRODCUTLISTXPATH = "//div[@class='ProductCard_productName__5Z65V']";
	public static final String PRODUCTRATINGXPATH = "//div[@class='Ratings_averageRating__RGGlG']";
	public static final String RATINGHEADXPATH = "//div[text()='Ratings and Reviews']";
	public static final String STARSXPATH = "//div[@class='OverviewSection_starsDiv___fLfB']";
	public static final String FILOPTXPATH = "//div[@class='FilterItem_filterTitle__n7zYh']";
	public static final String SORTBUTTONXPATH = "//input[@aria-hidden = 'true']/../../..";
	public static final String SORTBYPRICEHIGHTOLOWXPATH = "//li[text()='Price high to low']";
	public static final String SORTBYPRICELOWTOHIGHXPATH = "//li[text()='Price low to high']";
	public static final String ALLPRODUCTSPRICECLASSNAME = "ProductCard_salePrice__iLWF7";
	public static final String SORTBYDISCOUNTXPATH = "//li[text()='Discount']";
	public static final String ALLPRODUCTSDISCOUNTCLASSNAME = "ProductCard_discountPercent__hcWbO";
	

}
