package com.ust.pharmeasy.pageimpl;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.pharmeasy.base.Setup;
import com.ust.pharmeasy.exceptions.ElementNotClickableException;
import com.ust.pharmeasy.exceptions.ExceptionMessages;

public class BrowseAllMedicinePageImpl {
    WebDriver driver;

    public BrowseAllMedicinePageImpl(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
    @FindBy(className = "BrowseList_medicine__cQZkc")
    public List<WebElement> allmedicinelinks;
    
    public ProductPageImpl openProductByIndex(int index) {
        try {
            WebElement medicineLink = allmedicinelinks.get(index);
            if (!Setup.isElementClickable(medicineLink)) {
                throw new ElementNotClickableException(ExceptionMessages.ELEMENT_NOT_CLICKABLE);
            }
            medicineLink.click();
            return new ProductPageImpl(driver);
        } catch (IndexOutOfBoundsException e) {
            throw new IllegalArgumentException(ExceptionMessages.INDEX_OUT_OF_BOUNDS, e);
        } catch (Exception e) {
            throw new ElementNotClickableException(ExceptionMessages.FAILED_TO_OPEN_PRODUCT_PAGE, e);
        }
    }
    
    
}
