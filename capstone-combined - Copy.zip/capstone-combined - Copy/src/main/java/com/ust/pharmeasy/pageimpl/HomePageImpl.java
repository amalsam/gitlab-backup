package com.ust.pharmeasy.pageimpl;

import static org.testng.Assert.assertTrue;

import java.time.Duration;
import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ust.pharmeasy.base.Setup;
import com.ust.pharmeasy.exceptions.ElementNotFoundException;
import com.ust.pharmeasy.exceptions.ExceptionMessages;
import com.ust.pharmeasy.locators.HomepageLocators;

public class HomePageImpl {
    WebDriver driver;

    @FindBy(linkText = HomepageLocators.MEDICINE_LINK_TEXT)
    public WebElement medicineLink;

    @FindBy(linkText = HomepageLocators.LABTEST_LINK_TEXT)
    WebElement labTestsLink;

    @FindBy(linkText = HomepageLocators.HEALTHCARE_LINK_TEXT)
    WebElement healthCareLink;

    @FindBy(linkText = HomepageLocators.HEALTHBLOGS_LINK_TEXT)
    WebElement healthBolgsLink;

    @FindBy(linkText = HomepageLocators.PLUS_LINK_TEXT)
    WebElement plusLink;

    @FindBy(linkText = HomepageLocators.VALUESTORE_LINK_TEXT)
    WebElement valueStoreLink;

    @FindBy(xpath = HomepageLocators.PINCODE_XPATH)
    WebElement selectPincodeLink;

    @FindBy(linkText = HomepageLocators.FAQ_LINK_TEXT)
    WebElement faqLink;

    @FindBy(xpath = HomepageLocators.UPLOADNOWBTN_XPATH)
    WebElement uploadNowBtn;

    @FindBy(xpath = HomepageLocators.SEARCHSUGGESSIONLIST_XPATH)
    List<WebElement> searchSuggessionList;

    @FindBy(css = HomepageLocators.SEARCHBAR_CSS)
    public WebElement searchBar;

    @FindBy(xpath = HomepageLocators.PREVIOUSLYBROWSED_XPATH)
    public WebElement previouslyBrowsedProduct;

    @FindBy(linkText = HomepageLocators.OFFERS_LINK_TEXT)
    public WebElement offersLink;

    @FindBy(linkText = HomepageLocators.LOGIN_LINK_TEXT)
    public WebElement loginLink;

    @FindBy(css = HomepageLocators.NUMBERFIELD_CSS)
    public WebElement numberField;

    @FindBy(css = HomepageLocators.SEND_OTP_BTN_XPATH)
    public WebElement sendOTPButton;

    @FindBy(xpath = HomepageLocators.CLICKTOSEARCH_XPATH)
    WebElement clickToSearch;

    @FindBy(linkText = HomepageLocators.BROWSEALLSTORES_LINK_TEXT)
    WebElement browseAllStores;


    @FindBy(css = HomepageLocators.ADDNEW_ADDRESS_CSS)
    WebElement addNewAddress;

    @FindBy(xpath = HomepageLocators.PINCODELINK_XPATH)
    WebElement pinLink;

    @FindBy(xpath = HomepageLocators.PINCODEFIELD_XPATH)
    WebElement pinField;

    @FindBy(xpath = HomepageLocators.SUBMIT_BTN_XPATH)
    WebElement submitBtn;

    @FindBy(xpath = HomepageLocators.ERROR_MSG_XPATH)
    WebElement errorMsg;
    
    @FindBy(linkText = HomepageLocators.BROWSE_ALL_MED_LINKTEXT)
    public WebElement browseAllMedicine;
    
    @FindBy(xpath = HomepageLocators.PREVIOUSLYBROWSED_XPATH)
	public WebElement prevoislyBrowsedProduct;
    
    
    
    WebElement cart;

    public HomePageImpl(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    /******************************By Amal Sam ***************************/
    public UploadPrescriptionPageImpl clickUploadNow() {
        uploadNowBtn.click();
        return new UploadPrescriptionPageImpl(driver);
    }

    public ProductPageImpl clickSearchSuggessionItem(int itemNo) {
        try {
            Setup.wait(2);
            Setup.waitUntil(searchSuggessionList.get(itemNo - 1)).click();
            return new ProductPageImpl(driver);
        } catch (NoSuchElementException e) {
            throw new ElementNotFoundException(ExceptionMessages.SEARCH_SUGGESTION_NOT_FOUND, e);
        }
    }

    public HealthCarePageImpl openHealthCarePage() {
        healthCareLink.click();
        return new HealthCarePageImpl(driver);
    }

    public FaqMainPageImpl openFaqPage() {
        faqLink.click();
        return new FaqMainPageImpl(driver);
    }

    public OffersPageImpl openOffersPage() {
        offersLink.click();
        return new OffersPageImpl(driver);
    }

    /****************************By Abhinav*****************************************/
    public LabTestPageImpl labTestClick() {
        labTestsLink.click();
        return new LabTestPageImpl(driver);
    }

    public HealthCareProductPageImpl clickHealthProduct() {
        healthCareLink.click();
        return new HealthCareProductPageImpl(driver);
    }

    public void scrolltoFooter() {
        Setup.justscroll(0, 7800);
    }

    public AllStoresPageImpl clickBrowseAllStores() {
        browseAllStores.click();
        return new AllStoresPageImpl(driver);
    }

    public PlusPageImpl clickPlus() {
        plusLink.click();
        return new PlusPageImpl(driver);
    }

    public void clickPinLink() {
        Setup.wait(2);
        pinLink.click();
    }

    public void sendPincode(String pincode) {
        Setup.wait(2);
        pinField.click();
        pinField.sendKeys(pincode);
    }

    public void clickSubmit() {
        submitBtn.click();
    }

    public String getPin() {
        return pinLink.getText().split(" ")[0];
    }

    public String getPlace() {
        return pinLink.getText().split(" ")[1];
    }

    public String getErrorMessage() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        wait.until(ExpectedConditions.visibilityOf(errorMsg));
        return errorMsg.getText();
    }
    
    public String errormessagfoundornot() {
    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
    			
    	wait.until(d->errorMsg.isDisplayed());
    	
    	return errorMsg.getText();
    }


    /***************************By Amal Jose ************************/
    WebElement topBarInput;

    public SearchResultPageImpl enterMedicineNameInSearchBar(String productName) {
        try {
            searchBar.click();
            topBarInput.clear();
            topBarInput.sendKeys(productName + Keys.ENTER);
            return new SearchResultPageImpl(driver);
        } catch (NoSuchElementException e) {
            throw new ElementNotFoundException(ExceptionMessages.ENTER_MEDICINE_NAME_FAILED, e);
        }
    }

    public void navigateThroughDifferentPages() {
        try {
            labTestsLink.click();
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            wait.until(ExpectedConditions.urlContains("diagnostics"));
            healthCareLink.click();
            wait.until(ExpectedConditions.urlContains("healthcare"));
        } catch (NoSuchElementException e) {
            throw new ElementNotFoundException(ExceptionMessages.NAVIGATE_PAGES_FAILED, e);
        }
    }

    public void verifyCartContainsProducts() {
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='cart-item']")));
            assertTrue(driver.findElement(By.xpath("//div[@class='cart-item']")).isDisplayed());
        } catch (NoSuchElementException e) {
            throw new ElementNotFoundException(ExceptionMessages.CART_EMPTY, e);
        }
    }

    public void goToCartPage() {
        try {
            cart.click(); // Assuming you have a WebElement named 'cart' initialized somewhere
        } catch (NoSuchElementException e) {
            throw new ElementNotFoundException(ExceptionMessages.GO_TO_CART_FAILED, e);
        }
    }

    public void updateProductQuantity() {
        try {
            WebElement quantityInput = driver.findElement(By.xpath("//input[@class='cart-quantity']"));
            quantityInput.clear();
            quantityInput.sendKeys("2");
            WebElement updateButton = driver.findElement(By.xpath("//button[@class='update-cart']"));
            updateButton.click();
        } catch (NoSuchElementException e) {
            throw new ElementNotFoundException(ExceptionMessages.UPDATE_QUANTITY_FAILED, e);
        }
    }

    public void verifyProductQuantityUpdated() {
        try {
            WebElement quantityInput = driver.findElement(By.xpath("//input[@class='cart-quantity']"));
            assertTrue(quantityInput.getAttribute("value").equals("2"));
        } catch (NoSuchElementException e) {
            throw new ElementNotFoundException(ExceptionMessages.QUANTITY_NOT_UPDATED, e);
        }
    }

    public BrowseAllMedicinePageImpl openBrowseAllMedicinePage() {
        browseAllMedicine.click();
        return new BrowseAllMedicinePageImpl(driver);
    }

	
}
