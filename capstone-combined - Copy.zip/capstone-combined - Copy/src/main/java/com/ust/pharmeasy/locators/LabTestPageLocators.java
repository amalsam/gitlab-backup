package com.ust.pharmeasy.locators;

public class LabTestPageLocators {
public static final String FULLBODYCHECKDIVXPATH = "(//div[text()='Comprehensive Full Body Checkup Test with Vitamin D & B12'])[1]/ancestor::a";
}
