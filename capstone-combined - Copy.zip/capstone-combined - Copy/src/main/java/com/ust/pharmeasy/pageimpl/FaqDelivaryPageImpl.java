package com.ust.pharmeasy.pageimpl;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.pharmeasy.exceptions.ElementNotClickableException;
import com.ust.pharmeasy.exceptions.ExceptionMessages;
import com.ust.pharmeasy.locators.FaqPagesLocators;

public class FaqDelivaryPageImpl {
    WebDriver driver;

    @FindBy(xpath = FaqPagesLocators.QUESTIONS_XPATH)
    List<WebElement> questionslink;

    public FaqDelivaryPageImpl(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public FaqQuestionsPageImpl openQuestion(int questionNo) {
        try {
            if (questionNo <= 0 || questionNo > questionslink.size()) {
                throw new IndexOutOfBoundsException(ExceptionMessages.INDEX_OUT_OF_BOUNDS);
            }
            
            questionslink.get(questionNo - 1).click();
            
            return new FaqQuestionsPageImpl(driver);
        } catch (IndexOutOfBoundsException e) {
            throw new IllegalArgumentException(ExceptionMessages.INDEX_OUT_OF_BOUNDS, e);
        } catch (Exception e) {
            throw new ElementNotClickableException(ExceptionMessages.ELEMENT_NOT_CLICKABLE, e);
        }
    }
}
