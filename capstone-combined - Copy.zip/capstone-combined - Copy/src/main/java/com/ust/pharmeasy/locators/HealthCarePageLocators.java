package com.ust.pharmeasy.locators;

public class HealthCarePageLocators {
	public static final String TOPPRODUCTBTNXPATH = "//h2[text()='Trending Products']/ancestor::a";
	public static final String TOPPRODUCTLINKXPATH = "(//a[@data-id = 'category-landing'])[1]";

}
