package com.ust.pharmeasy.pageimpl;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.pharmeasy.exceptions.ElementNotClickableException;
import com.ust.pharmeasy.exceptions.ExceptionMessages;
import com.ust.pharmeasy.locators.FaqPagesLocators;

public class FaqMainPageImpl {
    WebDriver driver;

    @FindBy(partialLinkText = FaqPagesLocators.MED_HEALTHCARE_LINK_TEXT)
    public WebElement medicineAndHealthcareBtn;

    @FindBy(partialLinkText = FaqPagesLocators.DELIVARY_LINK_TEXT)
    public WebElement deliveryBtn;

    @FindBy(partialLinkText = FaqPagesLocators.PAYMENTS_LINK_TEXT)
    public WebElement paymentsBtn;

    @FindBy(partialLinkText = FaqPagesLocators.DIAGNOSTICS_LINK_TEXT)
    public WebElement diagnosticsBtn;

    public FaqMainPageImpl(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public FaqMedicineAndHealthCarePageImpl openMedicineAndHealthCare() {
        try {
            medicineAndHealthcareBtn.click();
            return new FaqMedicineAndHealthCarePageImpl(driver);
        } catch (Exception e) {
            throw new ElementNotClickableException(ExceptionMessages.ELEMENT_NOT_CLICKABLE, e);
        }
    }

    public FaqPaymentsPageImpl openPaymentFaq() {
        try {
            paymentsBtn.click();
            return new FaqPaymentsPageImpl(driver);
        } catch (Exception e) {
            throw new ElementNotClickableException(ExceptionMessages.ELEMENT_NOT_CLICKABLE, e);
        }
    }

    public FaqDiagnosticsPageImpl openDiagnosticsFaq() {
        try {
            diagnosticsBtn.click();
            return new FaqDiagnosticsPageImpl(driver);
        } catch (Exception e) {
            throw new ElementNotClickableException(ExceptionMessages.ELEMENT_NOT_CLICKABLE, e);
        }
    }

    public FaqDelivaryPageImpl openDelivaryFaq() {
        try {
            deliveryBtn.click();
            return new FaqDelivaryPageImpl(driver);
        } catch (Exception e) {
            throw new ElementNotClickableException(ExceptionMessages.ELEMENT_NOT_CLICKABLE, e);
        }
    }
}
