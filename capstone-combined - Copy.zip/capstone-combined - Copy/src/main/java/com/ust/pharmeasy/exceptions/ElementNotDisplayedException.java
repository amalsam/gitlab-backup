package com.ust.pharmeasy.exceptions;

public class ElementNotDisplayedException extends RuntimeException {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ElementNotDisplayedException() {
        super();
    }

    public ElementNotDisplayedException(String message) {
        super(message);
    }

    public ElementNotDisplayedException(String message, Throwable cause) {
        super(message, cause);
    }

    public ElementNotDisplayedException(Throwable cause) {
        super(cause);
    }
}
