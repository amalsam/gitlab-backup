package com.ust.pharmeasy.locators;

public class FaqPagesLocators {
	public static final String MED_HEALTHCARE_LINK_TEXT = "Medicine & Healthcare Orders";
	public static final String DELIVARY_LINK_TEXT ="Delivery";
	public static final String PAYMENTS_LINK_TEXT ="Payments";
	public static final String DIAGNOSTICS_LINK_TEXT ="Diagnostics";
	public static final String QUESTIONS_XPATH = "(//a[@class='d22JE'])";
	public static final String QUESTION_TITLE_CLASS= "_2yJoZ";
	
	

}
