package com.ust.pharmeasy.pageimpl;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import com.ust.pharmeasy.exceptions.ElementNotClickableException;
import com.ust.pharmeasy.exceptions.ElementNotDisplayedException;
import com.ust.pharmeasy.exceptions.ElementNotFoundException;
import com.ust.pharmeasy.exceptions.ExceptionMessages;
import com.ust.pharmeasy.locators.ProductPageLocators;

public class ProductImpl {

    WebDriver driver;

    @FindBy(xpath = ProductPageLocators.BOOKTESTXPATH)
    WebElement bookTestButton;

    @FindBy(xpath = ProductPageLocators.CHOOSEPATIENTXPATH)
    WebElement choosePatientButton;

    @FindBy(id = ProductPageLocators.TESTNAMEID)
    WebElement testNameElement;

    public ProductImpl(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void clickBookTest() {
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            wait.until(ExpectedConditions.elementToBeClickable(bookTestButton));
            bookTestButton.click();
        } catch (Exception e) {
            throw new ElementNotClickableException(ExceptionMessages.ELEMENT_NOT_CLICKABLE, e);
        }
    }

    public ProductCartPageImpl choosePatient() {
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            wait.until(ExpectedConditions.visibilityOf(choosePatientButton));
            choosePatientButton.click();
            return new ProductCartPageImpl(driver);
        } catch (Exception e) {
            throw new ElementNotDisplayedException(ExceptionMessages.ELEMENT_NOT_DISPLAYED, e);
        }
    }

    public String getProductName() {
        try {
            return testNameElement.getText();
        } catch (Exception e) {
            throw new ElementNotFoundException(ExceptionMessages.ELEMENT_NOT_FOUND, e);
        }
    }
}
