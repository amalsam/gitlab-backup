package com.ust.pharmeasy.locators;

public class AllStoresPageLocators {
	public static final String FILTERBTNXPATH = "//div[@tabindex='0']";

}
