package com.ust.pharmeasy.exceptions;


public class ElementNotClickableException extends RuntimeException {

  
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ElementNotClickableException(String message) {
        super(message);
    }

    public ElementNotClickableException(String message, Throwable cause) {
        super(message, cause);
    }
}