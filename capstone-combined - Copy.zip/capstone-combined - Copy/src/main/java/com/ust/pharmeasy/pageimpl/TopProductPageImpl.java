package com.ust.pharmeasy.pageimpl;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ust.pharmeasy.base.Setup;
import com.ust.pharmeasy.exceptions.ExceptionMessages;
import com.ust.pharmeasy.locators.TopProductPageLocators;

public class TopProductPageImpl {
    WebDriver driver;

    @FindBy(xpath = TopProductPageLocators.VITAMINXPATH)
    WebElement vitamin;
    
    @FindBy(xpath = TopProductPageLocators.VITAMINWAITXPATH)
    WebElement vitaminwait;
    
    @FindBy(xpath = TopProductPageLocators.LIVEASYXPATH)
    WebElement liveasy;
    
    @FindBy(xpath = TopProductPageLocators.BELOWNINENINEXPATH)
    WebElement belowninenine;
    
    @FindBy(xpath = TopProductPageLocators.TOPPRODCUTLISTXPATH)
    List<WebElement> topprodcutlist;
    
    @FindBy(xpath = TopProductPageLocators.PRODUCTRATINGXPATH)
    WebElement productRating;
    
    @FindBy(xpath = TopProductPageLocators.RATINGHEADXPATH)
    WebElement ratinghead;
    
    @FindBy(xpath = TopProductPageLocators.STARSXPATH)
    WebElement stars;
    
    @FindBy(xpath = TopProductPageLocators.FILOPTXPATH)
    List<WebElement> filopt;

    @FindBy(xpath = TopProductPageLocators.SORTBUTTONXPATH)
    WebElement sortButton;
    
    @FindBy(xpath = TopProductPageLocators.SORTBYPRICEHIGHTOLOWXPATH)
	public
    WebElement sortByPriceHighToLow;
    
    @FindBy(xpath = TopProductPageLocators.SORTBYPRICELOWTOHIGHXPATH)
	public
    WebElement sortByPriceLowToHigh;
    
    @FindBy(className = TopProductPageLocators.ALLPRODUCTSPRICECLASSNAME)
    List<WebElement> allProductsPrice;
    
    @FindBy(xpath = TopProductPageLocators.SORTBYDISCOUNTXPATH)
	public
    WebElement sortByDiscount;
    
    @FindBy(className = TopProductPageLocators.ALLPRODUCTSDISCOUNTCLASSNAME)
    List<WebElement> allProductsDiscount;

    public TopProductPageImpl(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void chooseVitamin() {
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            wait.until(d -> vitaminwait.isDisplayed());
            vitamin.click();
        } catch (Exception e) {
            throw new RuntimeException(ExceptionMessages.GENERAL_EXCEPTION, e);
        }
    }

    public void chooseLiveasy() {
        try {
            liveasy.click();
        } catch (Exception e) {
            throw new RuntimeException(ExceptionMessages.GENERAL_EXCEPTION, e);
        }
    }

    public void filterCheckbox(String opt) {
        try {
            int id = Setup.findValue(opt, topprodcutlist);
            filopt.get(id).click();
        } catch (Exception e) {
            throw new RuntimeException(ExceptionMessages.GENERAL_EXCEPTION, e);
        }
    }

    public void choosePrice() {
        try {
            belowninenine.click();
        } catch (Exception e) {
            throw new RuntimeException(ExceptionMessages.GENERAL_EXCEPTION, e);
        }
    }

    public ProductCartPageImpl clickOnProduct(String productName) {
        try {
            int id = Setup.findValue(productName, topprodcutlist);
            topprodcutlist.get(id).click();
            return new ProductCartPageImpl(driver);
        } catch (Exception e) {
            throw new RuntimeException(ExceptionMessages.GENERAL_EXCEPTION, e);
        }
    }

    public void clickRating() {
        try {
            stars.click();
        } catch (Exception e) {
            throw new RuntimeException(ExceptionMessages.GENERAL_EXCEPTION, e);
        }
    }

    public String getRatingValue() {
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            wait.until(d -> ratinghead.isDisplayed());
            return productRating.getText();
        } catch (Exception e) {
            throw new RuntimeException(ExceptionMessages.GENERAL_EXCEPTION, e);
        }
    }

    public void clickSort() {
        try {
            sortButton.click();
        } catch (Exception e) {
            throw new RuntimeException(ExceptionMessages.GENERAL_EXCEPTION, e);
        }
    }

    public boolean isProductsSortedByPriceHighToLow() {
       
            int n = allProductsPrice.size();
            for (int i = 0; i < n - 1; i++) {
                WebElement e1 = allProductsPrice.get(i);
                WebElement e2 = allProductsPrice.get(i + 1);
                Double price1 = convertPriceToDouble(e1.getText());
                Double price2 = convertPriceToDouble(e2.getText());
                if (price1 < price2) return false;
            }
            return true;
       
    }

    public boolean isProductsSortedByPriceLowToHigh() {
        
            int n = allProductsPrice.size();
            for (int i = 0; i < n - 1; i++) {
                WebElement e1 = allProductsPrice.get(i);
                WebElement e2 = allProductsPrice.get(i + 1);
                Double price1 = convertPriceToDouble(e1.getText());
                Double price2 = convertPriceToDouble(e2.getText());
                if (price1 > price2) return false;
            }
            return true;
       
    }

    public boolean isProductsSortedByDiscount() {
        
            int n = allProductsDiscount.size();
            for (int i = 0; i < n - 1; i++) {
                WebElement e1 = allProductsDiscount.get(i);
                WebElement e2 = allProductsDiscount.get(i + 1);
                int discountOfe1 = convertDiscountToInt(e1.getText());
                int discountOfe2 = convertDiscountToInt(e2.getText());
                if (discountOfe2 > discountOfe1) return false;
            }
            return true;
        
    }

    private Double convertPriceToDouble(String s) {
        s = s.replace("₹", "");
        s = s.replace("MRP ", "");
        return Double.parseDouble(s);
    }

    private int convertDiscountToInt(String s) {
        s = s.replace("% OFF", "");
        return Integer.parseInt(s);
    }
}
