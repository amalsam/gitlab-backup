package com.ust.pharmeasy.pageimpl;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.pharmeasy.base.Setup;
import com.ust.pharmeasy.exceptions.ElementNotClickableException;
import com.ust.pharmeasy.exceptions.ElementNotFoundException;
import com.ust.pharmeasy.exceptions.ExceptionMessages;
import com.ust.pharmeasy.locators.AllStoresPageLocators;

public class AllStoresPageImpl {
	WebDriver driver;

	public AllStoresPageImpl(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = AllStoresPageLocators.FILTERBTNXPATH)
	WebElement filterbutton;

	public void clickFilterbtn() {
		try {
			filterbutton.click();
			Setup.wait(2); 
		} catch (Exception e) {
			throw new ElementNotClickableException(ExceptionMessages.ELEMENT_NOT_CLICKABLE, e);
		}
	}
	
	

	public void chooseoption(String opt) {
		try {
			List<WebElement> listoption = driver.findElements(By.cssSelector("ul > li"));
			int id = Setup.findValue(opt, listoption);
			if (id == -1) {
				throw new ElementNotFoundException(ExceptionMessages.OPTION_NOT_FOUND + ": " + opt);
			}
			listoption.get(id).click();
		} catch (NoSuchElementException e) {
			throw new ElementNotFoundException(ExceptionMessages.ELEMENT_NOT_FOUND + ": " + opt, e);
		} catch (Exception e) {
			throw new ElementNotFoundException(ExceptionMessages.FAILED_TO_CLICK_OPTION + ": " + opt, e);
		}
	}
	
	
	

	public void anotherchoose(String opt) {
		try {
			driver.findElement(By.xpath("//li[text()='" + opt + "']")).click();
		} catch (NoSuchElementException e) {
			throw new ElementNotFoundException(ExceptionMessages.OPTION_NOT_FOUND + ": " + opt, e);
		} catch (Exception e) {
			throw new ElementNotClickableException(ExceptionMessages.FAILED_TO_CLICK_OPTION + ": " + opt, e);
		}
	}
	
	
	

	public boolean checkFilterResult(String opt) {
		List<WebElement> result = driver.findElements(By.xpath("//p[@class='_3tsd0']"));
		for (WebElement e : result) {
			if (!(e.getText().contains(opt))) {
				return false;
			}
		}
		return true;
	}
	
	
}
