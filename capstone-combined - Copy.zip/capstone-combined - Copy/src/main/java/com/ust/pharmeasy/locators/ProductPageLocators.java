package com.ust.pharmeasy.locators;

public class ProductPageLocators {
	
	public static final String BOOKTESTXPATH = "//button[@id='book-test-btn-pdp']";
	public static final String CHOOSEPATIENTXPATH = "//h3[@id='undefined-patient-1']";
	public static final String TESTNAMEID = "test-name-pdp";
	
	
	
	public static final String PRESCRIPTIONREQUIREDICONCLASSNAME = "PDPDesktop_rxIconContainer__hIPxa";
	public static final String PRESCRIPTIONREQUIREDMSGID = "tippy-3";
	public static final String HOMEPAGEICONCSSSELECTOR = "a.ClickableElement_clickable__ItKj2.Logo_container__F7rHL";
	
	
	
	public static final String SEARCHBARID = "searchBar";
	public static final String ADDTOCARTICONLINKTEXT = "cart";
	public static final String QUANTITYADDXPATH = "//li[@data-value='2']";
	public static final String ALLCARTCLASSNAME = "styles_heading__VzA1y";
	public static final String DOSAGELINKTEXT = "Dosage";
	public static final String SIDEEFFECTSLINKTEXT = "Side effects";
	public static final String INTERACTIONSLINKTEXT = "Interactions";
	public static final String HINDIBUTTONLINKTEXT = "हिंदी में पढ़ें";
	public static final String PRODUCTNAMEXPATH = "//h1[@class=\"MedicineOverviewSection_medicineName__dHDQi\"]";
	public static final String ADDTOCARTBTNID = "proceed";
	public static final String HEADINGSCLASSNAME = "Heading_title__gZp5c";
	public static final String FREQUENTLYBOUGHTXPATH = "//div[@class=\"Recommendations_heading__HSO2I\"]";
	public static final String PRODUCTNAMXPATH = "//div[@class=\"OverviewSection_nameContainer__VElyz\"]";
	public static final String VIEWCARTCLASSNAME = "Navigation_notificationCountBubble__G4f_P";
	

}
