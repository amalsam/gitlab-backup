package com.ust.pharmeasy.locators;

public class SearchResultPageLocators {

	
	public static final String SEARCHBARID = "topBarInput";
	public static final String PRODUCTFROMSEARCHRESULTSCLASSNAME = "ProductCard_medicineUnitWrapper__eoLpy";
	public static final String ALLPRODUCTCLASSNAME = "ProductCard_medicineName__8Ydfq";
	
}
