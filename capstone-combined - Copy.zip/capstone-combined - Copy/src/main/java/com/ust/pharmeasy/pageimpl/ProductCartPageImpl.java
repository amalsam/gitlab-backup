package com.ust.pharmeasy.pageimpl;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ust.pharmeasy.base.Setup;

import com.ust.pharmeasy.exceptions.ElementNotClickableException;
import com.ust.pharmeasy.exceptions.ElementNotDisplayedException;
import com.ust.pharmeasy.exceptions.ElementNotFoundException;
import com.ust.pharmeasy.exceptions.ExceptionMessages;
import com.ust.pharmeasy.locators.CartpageLocators;

public class ProductCartPageImpl {
    WebDriver driver;

    @FindBy(xpath = CartpageLocators.POPUP_XPATH)
    WebElement popup;

    @FindBy(xpath = CartpageLocators.PROCEED_BTN_XPATH)
    WebElement proceedBtn;

    @FindBy(className = CartpageLocators.DISCOUNTCLASSNAME)
    WebElement discount;

    @FindBy(className = CartpageLocators.MRPCLASSNAME)
    WebElement mrp;

    @FindBy(className = CartpageLocators.PRICECLASSNAME)
    WebElement price;

    @FindBy(linkText = CartpageLocators.CARTLINKTEXT)
    WebElement cartLink;

    @FindBy(id = CartpageLocators.PRODUCTNID)
    WebElement productElement;

    public ProductCartPageImpl(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void clickProceed() {
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(4));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(CartpageLocators.PROCEED_BTN_XPATH)));
            proceedBtn.click();
        } catch (Exception e) {
            throw new ElementNotClickableException(ExceptionMessages.ELEMENT_NOT_CLICKABLE, e);
        }
    }

    public boolean checkPopup() {
        try {
            Setup.wait(1);
            return popup.isDisplayed();
        } catch (Exception e) {
            throw new ElementNotDisplayedException(ExceptionMessages.ELEMENT_NOT_DISPLAYED, e);
        }
    }

    public float findExpectedProductPrice() {
        try {
            String discountText = discount.getText();
            String mrpText = mrp.getText();
            return Setup.afterdiscount(Setup.strtoint(mrpText), Setup.getDiscount(discountText));
        } catch (Exception e) {
            throw new ElementNotFoundException(ExceptionMessages.ELEMENT_NOT_FOUND, e);
        }
    }

    public float findActualProductPrice() {
        try {
            String priceText = price.getText();
            return Setup.strtoint(priceText);
        } catch (Exception e) {
            throw new ElementNotFoundException(ExceptionMessages.ELEMENT_NOT_FOUND, e);
        }
    }

    public void clickCart() {
        try {
            cartLink.click();
        } catch (Exception e) {
            throw new ElementNotClickableException(ExceptionMessages.ELEMENT_NOT_CLICKABLE, e);
        }
    }

    public String getCartedProductName() {
        try {
        	Setup.wait(2);
            return productElement.getText();
        } catch (Exception e) {
            throw new ElementNotFoundException(ExceptionMessages.ELEMENT_NOT_FOUND, e);
        }
    }
}
