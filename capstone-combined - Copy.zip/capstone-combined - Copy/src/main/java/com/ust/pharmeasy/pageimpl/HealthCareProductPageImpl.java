package com.ust.pharmeasy.pageimpl;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.pharmeasy.exceptions.ElementNotClickableException;
import com.ust.pharmeasy.exceptions.ExceptionMessages;
import com.ust.pharmeasy.locators.HealthCarePageLocators;

public class HealthCareProductPageImpl {
    WebDriver driver;

    @FindBy(xpath = HealthCarePageLocators.TOPPRODUCTLINKXPATH)
    WebElement topProductLink;

    public HealthCareProductPageImpl(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public TopProductPageImpl clickTopProduct() {
        try {
            topProductLink.click();
            return new TopProductPageImpl(driver);
        } catch (Exception e) {
            throw new ElementNotClickableException(ExceptionMessages.ELEMENT_NOT_CLICKABLE + HealthCarePageLocators.TOPPRODUCTLINKXPATH, e);
        }
    }
}
