package com.ust.pharmeasy.locators;

public class CartpageLocators {
	public static final String POPUP_XPATH = "//div[text()='Quick Login / Register']";
	public static final String PROCEED_BTN_XPATH = "//button[@id='cart-addPatient-Dweb']";
	public static final String DISCOUNTCLASSNAME = "ProductPriceContainer_discountContainer___vEl5";
	public static final String MRPCLASSNAME = "ProductPriceContainer_striked__hkuDD";
	public static final String PRICECLASSNAME = "ProductPriceContainer_mrp__mDowM";
	public static final String CARTLINKTEXT = "Cart";
	public static final String PRODUCTNID = "cart-card-0-title";

}
