package com.ust.pharmeasy.pageimpl;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.pharmeasy.exceptions.ElementNotClickableException;
import com.ust.pharmeasy.exceptions.ElementNotDisplayedException;
import com.ust.pharmeasy.exceptions.ExceptionMessages;
import com.ust.pharmeasy.locators.OffersPageLocators;

public class OffersPageImpl {
    WebDriver driver;

    @FindBy(xpath = OffersPageLocators.PAYMENTBTNXPATH)
    public WebElement paymentBtn;
    
    @FindBy(xpath = OffersPageLocators.MEDICINEBTNXPATH)
    public WebElement medicineBtn;
    
    @FindBy(xpath = OffersPageLocators.DIAGONOSTICSBTN)
    public WebElement diagnosticsBtn;
    
    @FindBy(xpath = OffersPageLocators.HEALTHCAREBTNXPATH)
    public WebElement healthcareBtn;
    
    @FindBy(className = OffersPageLocators.OFFERSLISTCLASSNAME)
    List<WebElement> offersList;

    public OffersPageImpl(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public String getFirstOfferText() {
        try {
            if (!offersList.isEmpty()) {
                return offersList.get(0).getText();
            } else {
                throw new ElementNotDisplayedException(ExceptionMessages.ELEMENT_NOT_DISPLAYED + OffersPageLocators.OFFERSLISTCLASSNAME);
            }
        } catch (Exception e) {
            throw new ElementNotDisplayedException(ExceptionMessages.ELEMENT_NOT_DISPLAYED + OffersPageLocators.OFFERSLISTCLASSNAME, e);
        }
    }

    public void clickPaymentButton() {
        try {
            paymentBtn.click();
        } catch (Exception e) {
            throw new ElementNotClickableException(ExceptionMessages.ELEMENT_NOT_CLICKABLE + OffersPageLocators.PAYMENTBTNXPATH, e);
        }
    }

    public void clickMedicineButton() {
        try {
            medicineBtn.click();
        } catch (Exception e) {
            throw new ElementNotClickableException(ExceptionMessages.ELEMENT_NOT_CLICKABLE + OffersPageLocators.MEDICINEBTNXPATH, e);
        }
    }

    public void clickDiagnosticsButton() {
        try {
            diagnosticsBtn.click();
        } catch (Exception e) {
            throw new ElementNotClickableException(ExceptionMessages.ELEMENT_NOT_CLICKABLE + OffersPageLocators.DIAGONOSTICSBTN, e);
        }
    }

    public void clickHealthcareButton() {
        try {
            healthcareBtn.click();
        } catch (Exception e) {
            throw new ElementNotClickableException(ExceptionMessages.ELEMENT_NOT_CLICKABLE + OffersPageLocators.HEALTHCAREBTNXPATH, e);
        }
    }
}
