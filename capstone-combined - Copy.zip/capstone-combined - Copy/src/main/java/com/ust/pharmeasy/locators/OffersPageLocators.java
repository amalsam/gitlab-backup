package com.ust.pharmeasy.locators;

public class OffersPageLocators {
public static final String	PAYMENTBTNXPATH =	"//div[text()='Payment']";
public static final String	MEDICINEBTNXPATH =    "//div[text()='Medicine']";
public static final String	DIAGONOSTICSBTN =    "//div[text()='Diagnostic']";
public static final String	HEALTHCAREBTNXPATH =    "//div[text()='Healthcare']";
public static final String	OFFERSLISTCLASSNAME =    "OffersCard_title__nX7J_";
}
