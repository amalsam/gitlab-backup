package com.ust.pharmeasy.pageimpl;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.pharmeasy.exceptions.ElementNotFoundException;
import com.ust.pharmeasy.exceptions.ExceptionMessages;
import com.ust.pharmeasy.locators.FaqPagesLocators;

public class FaqQuestionsPageImpl {

    WebDriver driver;

    @FindBy(className = FaqPagesLocators.QUESTION_TITLE_CLASS)
    WebElement questionTitle;

    public FaqQuestionsPageImpl(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public String getQuestionTitle() {
        try {
            if (questionTitle == null) {
                throw new ElementNotFoundException(ExceptionMessages.ELEMENT_NOT_FOUND + FaqPagesLocators.QUESTION_TITLE_CLASS);
            }
            return questionTitle.getText();
        } catch (Exception e) {
            throw new ElementNotFoundException(ExceptionMessages.FAILED_TO_GET_QUESTION_TITLE, e);
        }
    }
}
