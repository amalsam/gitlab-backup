package com.ust.pharmeasy.locators;

public class UploadPrescriptionPageLocators {
	
	public static final String UPLOADFILECSSSELECTOR = "uploadFile";
	public static final String UPLOADEDFILECSSSELECTOR = "uploadedFile";
	public static final String ERRMSGCLASSNAME = "errMsg";
	

}
