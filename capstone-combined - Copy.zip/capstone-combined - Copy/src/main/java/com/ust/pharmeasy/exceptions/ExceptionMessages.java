package com.ust.pharmeasy.exceptions;

public class ExceptionMessages {

    public static final String ELEMENT_NOT_CLICKABLE = "Element is not clickable";
    public static final String INDEX_OUT_OF_BOUNDS = "Index is out of bounds for allmedicinelinks";
    public static final String FAILED_TO_OPEN_PRODUCT_PAGE = "Failed to open product page";

    public static final String ELEMENT_NOT_FOUND = "Element not found";
    public static final String OPTION_NOT_FOUND = "Option not found";
    public static final String FAILED_TO_CLICK_OPTION = "Failed to click option";
    public static final String FAILED_TO_CHECK_FILTER_RESULT = "Failed to check filter result";
    
    public static final String ELEMENT_NOT_DISPLAYED = "Element is not displayed";

    public static final String FAILED_TO_CLICK = "Failed to click element";
    public static final String TEXT_NOT_FOUND_IN_PRODUCTS = "Text not found in cart products";
    
    public static final String FAILED_TO_CLICK_QUESTION = "Failed to click question link";
    public static final String FAILED_TO_GET_QUESTION_TITLE = "Failed to get question title";

    public static final String ELEMENT_CLICK_FAILED = "Failed to click element";

    public static final String TIMEOUT_EXCEPTION = "Timeout waiting for element";
    public static final String GENERAL_EXCEPTION = "Exception occurred";
    
    public static final String SEARCH_SUGGESTION_NOT_FOUND = "Search suggestion item not found";
    public static final String ENTER_MEDICINE_NAME_FAILED = "Failed to enter medicine name in search bar";
    public static final String NAVIGATE_PAGES_FAILED = "Failed to navigate through different pages";
    public static final String CART_EMPTY = "Cart does not contain products";
    public static final String GO_TO_CART_FAILED = "Failed to go to cart page";
    public static final String UPDATE_QUANTITY_FAILED = "Failed to update product quantity";
    public static final String QUANTITY_NOT_UPDATED = "Product quantity not updated as expected";


}
