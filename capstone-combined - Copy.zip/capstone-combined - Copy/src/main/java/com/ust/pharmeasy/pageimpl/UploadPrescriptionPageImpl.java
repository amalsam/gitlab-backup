package com.ust.pharmeasy.pageimpl;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.pharmeasy.base.Setup;
import com.ust.pharmeasy.locators.UploadPrescriptionPageLocators;

public class UploadPrescriptionPageImpl {
	WebDriver driver;
	
	
	@FindBy(css = UploadPrescriptionPageLocators.UPLOADFILECSSSELECTOR)public WebElement uploadFile;
	@FindBy(css = UploadPrescriptionPageLocators.UPLOADEDFILECSSSELECTOR)public WebElement uploadedFile;
	@FindBy(className = UploadPrescriptionPageLocators.ERRMSGCLASSNAME)WebElement errMsg;
	public UploadPrescriptionPageImpl(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	public boolean isUploadedFileDisplayed() {
		try {
			Setup.wait(5);
			Setup.waitUntil(uploadedFile);
			return uploadedFile.isDisplayed();
			
		} catch (WebDriverException e) {
			System.out.println("NOtdissplayed");
			return false;
		}
	}
	
	public boolean isErrorMsgDisplayed() {
		try {
			return errMsg.isDisplayed();
		} catch (WebDriverException e) {
			return false;
		}
		
	}

}
