package com.ust.pharmeasy.pageimpl;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ust.pharmeasy.base.Setup;
import com.ust.pharmeasy.exceptions.ExceptionMessages;
import com.ust.pharmeasy.locators.HomepageLocators;
import com.ust.pharmeasy.locators.ProductPageLocators;

public class ProductPageImpl {
	WebDriver driver;
	
	
	/*************************By Amal Sam ****************************/
	
	
	@FindBy(className = ProductPageLocators.PRESCRIPTIONREQUIREDICONCLASSNAME )
	WebElement prescriptionRequiredIcon;
	
	@FindBy(id = ProductPageLocators.PRESCRIPTIONREQUIREDMSGID)
	WebElement prescriptionRequiredMsg;
	
	@FindBy(css = ProductPageLocators.HOMEPAGEICONCSSSELECTOR )
	WebElement homepageIcon;

	
	public ProductPageImpl(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public boolean isPrescriptionRequired() {
        try {
            prescriptionRequiredIcon.click();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public HomePageImpl openHomepage() {
        try {
            homepageIcon.click();
            return new HomePageImpl(driver);
        } catch (Exception e) {
            throw new RuntimeException(ExceptionMessages.GENERAL_EXCEPTION, e);
        }
    }

   
	
	
	
	
	/*************************By Amal Jose ****************************/
	
	@FindBy(id = ProductPageLocators.SEARCHBARID )
	WebElement searchBar;
	
	@FindBy(linkText = ProductPageLocators.ADDTOCARTICONLINKTEXT )
	public WebElement addToCartIcon;
	
	@FindBy(xpath = ProductPageLocators.QUANTITYADDXPATH)
	public WebElement quantityadd;
	

	@FindBy(className = ProductPageLocators.ALLCARTCLASSNAME)
	public List<WebElement> allcart;
	

	@FindBy(linkText = ProductPageLocators.DOSAGELINKTEXT )
	public WebElement Dosage;
	
	@FindBy(linkText = ProductPageLocators.SIDEEFFECTSLINKTEXT )
	public WebElement Sideeffects;
	
	@FindBy(linkText = ProductPageLocators.INTERACTIONSLINKTEXT)
	public WebElement Interactions;
	
	
	//Hindi mem pado
	
	@FindBy(linkText = ProductPageLocators.HINDIBUTTONLINKTEXT)
	public WebElement hindibutton;
	
	
	@FindBy(xpath = ProductPageLocators.PRODUCTNAMEXPATH)
	public WebElement productname;
	
	@FindBy(id = ProductPageLocators.ADDTOCARTBTNID)
	public WebElement addtocartbtn;
	
	@FindBy(className = ProductPageLocators.HEADINGSCLASSNAME)
	public List<WebElement> headings;
	@FindBy(xpath = ProductPageLocators.FREQUENTLYBOUGHTXPATH )
	public WebElement frequentlybought;
	
	
	
	@FindBy(xpath = ProductPageLocators.PRODUCTNAMXPATH)
	public WebElement productnam;
	
	@FindBy(className= ProductPageLocators.VIEWCARTCLASSNAME)
	public WebElement viewCart;
	
	
	//also present in homepage
	@FindBy(linkText = HomepageLocators.LABTEST_LINK_TEXT)
	WebElement labTestsLink;
	
	@FindBy(linkText = HomepageLocators.HEALTHCARE_LINK_TEXT)
	WebElement healthCareLink;
	



	 public void enterMedicineNameInSearchBar(String productName) {
	        try {
	            Setup.waitUntil(searchBar).click();
	            searchBar.clear();
	            searchBar.sendKeys(productName + Keys.ENTER);
	        } catch (Exception e) {
	            throw new RuntimeException(ExceptionMessages.GENERAL_EXCEPTION, e);
	        }
	    }

	    public void clickAddtoCartButton() {
	        try {
	            Setup.waitUntil(addtocartbtn).click();
	        } catch (Exception e) {
	            throw new RuntimeException(ExceptionMessages.GENERAL_EXCEPTION, e);
	        }
	    }

	    public CartPageImpl openCartPage() {
	        try {
	            Setup.waitUntil(viewCart).click();
	            return new CartPageImpl(driver);
	        } catch (Exception e) {
	            throw new RuntimeException(ExceptionMessages.GENERAL_EXCEPTION, e);
	        }
	    }

	    public void navigateThroughDifferentPages() {
	        try {
	            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	            labTestsLink.click();
	            wait.until(ExpectedConditions.urlContains("diagnostics"));
	            healthCareLink.click();
	            wait.until(ExpectedConditions.urlContains("healthcare"));
	        } catch (Exception e) {
	            throw new RuntimeException(ExceptionMessages.GENERAL_EXCEPTION, e);
	        }
	    }
	}


