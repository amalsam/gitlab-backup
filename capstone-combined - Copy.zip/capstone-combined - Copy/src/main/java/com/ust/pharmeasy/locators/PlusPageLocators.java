package com.ust.pharmeasy.locators;

public class PlusPageLocators {
	
	public static final String CREDITSXPATH =	"//table[@class='style_breakDown__SjWYg']//tr[1]/td[2]";
	public static final String BREAKDOWNMONEYXPATH ="//table[@class='style_breakDown__SjWYg']//tr/td[2]";

}
