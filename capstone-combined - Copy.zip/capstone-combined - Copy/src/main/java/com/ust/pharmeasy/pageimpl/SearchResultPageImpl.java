package com.ust.pharmeasy.pageimpl;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ust.pharmeasy.base.Setup;
import com.ust.pharmeasy.exceptions.ExceptionMessages;
import com.ust.pharmeasy.locators.SearchResultPageLocators;

public class SearchResultPageImpl {
    WebDriver driver;
    WebDriverWait wait;

    @FindBy(id = SearchResultPageLocators.SEARCHBARID)
    WebElement searchBar;

    @FindBy(className = SearchResultPageLocators.PRODUCTFROMSEARCHRESULTSCLASSNAME)
    WebElement productFromSearchResults;

    @FindBy(className = SearchResultPageLocators.ALLPRODUCTCLASSNAME)
    public List<WebElement> allProduct;

    public SearchResultPageImpl(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofMillis(5000));
    }

    public void enterMedicineNameInSearchBar(String productName) {
        try {
            Setup.waitUntil(searchBar).click();
            searchBar.clear();
            searchBar.sendKeys(productName + Keys.ENTER);
        } catch (Exception e) {
            throw new RuntimeException(ExceptionMessages.GENERAL_EXCEPTION, e);
        }
    }

    public ProductPageImpl clickOnProductFromSearchResults() {
        try {
            Setup.waitUntil(productFromSearchResults).click();
            return new ProductPageImpl(driver);
        } catch (Exception e) {
            throw new RuntimeException(ExceptionMessages.GENERAL_EXCEPTION, e);
        }
    }
}
