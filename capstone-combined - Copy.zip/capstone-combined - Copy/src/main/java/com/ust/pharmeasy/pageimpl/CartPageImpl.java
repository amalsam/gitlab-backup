package com.ust.pharmeasy.pageimpl;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ust.pharmeasy.base.Setup;
import com.ust.pharmeasy.exceptions.ElementNotClickableException;
import com.ust.pharmeasy.exceptions.ExceptionMessages;
import com.ust.pharmeasy.locators.CartpageLocators;

public class CartPageImpl {
    WebDriver driver;

    public CartPageImpl(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = CartpageLocators.POPUP_XPATH)
    WebElement popupdiv;

    @FindBy(xpath = CartpageLocators.PROCEED_BTN_XPATH)
    WebElement proceedbtn;

    @FindBy(className = "styles_heading__VzA1y")
    public List<WebElement> allCartProductNames;

    public void clickProceed() {
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(4));
            wait.until(ExpectedConditions.visibilityOf(proceedbtn));
            proceedbtn.click();
        } catch (Exception e) {
            throw new ElementNotClickableException(ExceptionMessages.FAILED_TO_CLICK, e);
        }
    }

    public boolean checkpopupdiv() {
        Setup.wait(5);
        return popupdiv.isDisplayed();   
    }

    public boolean isTextPresentInCartProducts(String expectedText) {
        Setup.wait(5);
        for (WebElement productName : allCartProductNames) {
            if (productName.getText().equalsIgnoreCase(expectedText)) {
                return true;
            }
        }
        return false;
    }
}
