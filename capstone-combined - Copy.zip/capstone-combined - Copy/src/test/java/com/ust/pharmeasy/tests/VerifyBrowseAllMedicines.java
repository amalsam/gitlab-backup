package com.ust.pharmeasy.tests;

//by amal jose

import static org.testng.Assert.assertTrue;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.listeners.EventListenerClass;
import com.ust.pharmeasy.base.Setup;
import com.ust.pharmeasy.pageimpl.BrowseAllMedicinePageImpl;
import com.ust.pharmeasy.pageimpl.HomePageImpl;
import com.ust.pharmeasy.pageimpl.ProductPageImpl;

@Listeners(EventListenerClass.class)
public class VerifyBrowseAllMedicines {
	WebDriver driver;
	HomePageImpl homeP;
	ProductPageImpl productP;
	BrowseAllMedicinePageImpl browseAllMedP;

 
  
  

  @Test
  public void verifyUserAbleToBrowseAllMedicines()  {
      browseAllMedP = homeP.openBrowseAllMedicinePage();
      
      for(int i=0;i<10;i++) {
    	  productP = browseAllMedP.openProductByIndex(i);
    	 assertTrue( productP.frequentlybought.isDisplayed(),"Not dispalyed");
    	  driver.navigate().back();
    	  
      }
      

         
      
      
  }
  
  
  
  
  
  

	@BeforeMethod
	public void beforeMethod() {
		driver.get(Setup.prop.getProperty("baseurl"));
		homeP = new HomePageImpl(driver);
	}

	@BeforeClass
	public void beforeClass() {
//		new Setup();
//
//		driver = Setup.getBrowser(Setup.prop.getProperty("browser_for_testng"));
		driver = Setup.driver;
	}

	@AfterClass
	public void afterclass() {
		
	}
}