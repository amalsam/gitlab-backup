package com.ust.pharmeasy.stepdefinitions;
 

 
import org.openqa.selenium.WebDriver;
 
import com.ust.pharmeasy.base.Setup;

import io.cucumber.java.After;
import io.cucumber.java.Before;
 
public class Hooks {
	public static WebDriver driver;
@Before
public void beforemethod() {
	new Setup();
	driver = Setup.getBrowser( Setup.prop.getProperty("browser_for_cucumber"));	
}

@After
public void aftermethod() {
		driver.quit();
}
 
}
 