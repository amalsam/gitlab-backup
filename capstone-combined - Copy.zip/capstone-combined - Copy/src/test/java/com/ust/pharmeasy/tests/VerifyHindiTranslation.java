package com.ust.pharmeasy.tests;
//amaljose
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.listeners.EventListenerClass;
import com.ust.pharmeasy.base.Setup;

import com.ust.pharmeasy.pageimpl.CartPageImpl;
import com.ust.pharmeasy.pageimpl.HomePageImpl;
import com.ust.pharmeasy.pageimpl.ProductPageImpl;
import com.ust.pharmeasy.pageimpl.SearchResultPageImpl;

@Listeners(EventListenerClass.class)
public class VerifyHindiTranslation {
	WebDriver driver;
	HomePageImpl homeP;
	SearchResultPageImpl searchResultP;
	ProductPageImpl productP;
	CartPageImpl cartP;
	
	

	@Test(priority = 1)
	public void verifyProductNameInHindi() {
		searchResultP=homeP.enterMedicineNameInSearchBar("Ecosprin 75mg Strip Of 14 Tablets");
		productP = searchResultP.clickOnProductFromSearchResults();
		productP.hindibutton.click();
		Setup.wait(3);
		// Verify that the product name is displayed in Hindi
		String text1 = productP.productname.getText();
		// Assert that product name text is in Hindi
		assertTrue(containsHindiText(text1), "Product name is not in Hindi: " + text1);
	}

	
	
	
	@Test(priority = 2)
	public void verifyAddtocartBtnInHindi(){
		
		String text2 = productP.addtocartbtn.getText();
		assertTrue(containsHindiText(text2), "Add to cart button  is not in Hindi: " + text2);
	}

	

	
	
	
	@Test(priority = 3)
	public void verifywebpagenavigationwithhindi()  {
		// Verify that the webpage is displayed in Hindi after navigation
		productP.openHomepage();

		String text1 = homeP.medicineLink.getText();
		assertTrue(containsHindiText(text1), "Medicine tab is not in hindi" + text1);
	}

	
	
	
	//Helper method to check if a string contains Hindi characters
		private boolean containsHindiText(String text) {
			// Regular expression for detecting Hindi characters
			String hindiPattern = ".*[\\u0900-\\u097F]+.*";
			return text.matches(hindiPattern);
		}

	
		
		
		
	@BeforeClass
	public void beforeClass() {
//		new Setup();
//
//		driver = Setup.getBrowser(Setup.prop.getProperty("browser_for_testng"));
		driver = Setup.driver;
		driver.get(Setup.prop.getProperty("baseurl"));
		homeP = new HomePageImpl(driver);
	}

	@AfterClass
	public void afterclass() {
		
	}
}